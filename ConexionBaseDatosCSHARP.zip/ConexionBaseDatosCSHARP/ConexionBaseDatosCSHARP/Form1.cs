﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionBaseDatosCSHARP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLeer_Click(object sender, EventArgs e)
        {
            Conexion InstanciaConexion = new Conexion();
            // Devolver datos  - Primera Forma
            DataTable Resultados = new DataTable();
            Resultados=InstanciaConexion.EjercutarSentecia(" SELECT Nombre,Clave FROM productos ");
            dtgProductos.DataSource = Resultados;
            // Devolver datos - Segunda Forma 
            dtgProductos.DataSource = InstanciaConexion.EjercutarSentecia(" SELECT * FROM productos ");


        }
    }
}
