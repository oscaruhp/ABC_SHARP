﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConexionBaseDatosCSHARP.BO;
using System.Data;
namespace ConexionBaseDatosCSHARP.DAO
{
    class AlumnosDAO
    {
        Conexion Miconexion;
        public AlumnosDAO(){
            Miconexion = new Conexion();
        }
        public int Agregar(AlumnosBO oAlumnosBO) {
            String ComandoSQL = string.Format("INSERT INTO Alumnos(id,Nombre,Matricula) VALUES (null,'{0}','{1}')",oAlumnosBO.Nombre,oAlumnosBO.Matricula,oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);

        }
        public DataTable Buscar() { 
            // SELECT Para obtener los datos
            String ComandoSQLBUSQUEDA = String.Format("SELECT * FROM Alumnos");
            return Miconexion.EjercutarSentecia(ComandoSQLBUSQUEDA);
        }

        public int Eliminar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("DELETE FROM Alumnos WHERE id={0}", oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);

        }

        public int Modificar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("UPDATE Alumnos SET Nombre='{0}',Matricula='{1}' WHERE id={2}",oAlumnosBO.Nombre,oAlumnosBO.Matricula, oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);

        }
        

    }
}
