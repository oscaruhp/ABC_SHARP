﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ConexionBaseDatosCSHARP.BO;
using ConexionBaseDatosCSHARP.DAO;

namespace ConexionBaseDatosCSHARP.GUI
{
    public partial class frmAlumnosGUI : Form
    {
        AlumnosBO oAlumnosBO;
        AlumnosDAO oAlumnosDAO;

        public frmAlumnosGUI()
        {
            oAlumnosDAO = new AlumnosDAO();
            InitializeComponent();
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Agregar(RecuperarInformacion()) == 1)
            { MessageBox.Show("Datos Agregados"); }
            else { MessageBox.Show("Hay un error llamar al: 9991435789");  }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }
        private AlumnosBO RecuperarInformacion() {
            int id = 0;
            oAlumnosBO = new AlumnosBO();
            int.TryParse(txtClave.Text, out id);
            oAlumnosBO.ID = id;
            oAlumnosBO.Nombre = txtNombre.Text;
            oAlumnosBO.Matricula = txtMatricula.Text;
            return oAlumnosBO;
        
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Eliminar(RecuperarInformacion()) == 1)
            { MessageBox.Show("Dato eliminado"); }
            else { MessageBox.Show("Hay un error llamar al: 9991435789"); }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }

        private void SeleccionarRegistro(object sender, DataGridViewCellMouseEventArgs e)
        {
            int FilaSeleccionada = e.RowIndex;

            oAlumnosBO = new AlumnosBO();
            oAlumnosBO.ID = int.Parse(dtgAlumnos.Rows[FilaSeleccionada].Cells[0].Value.ToString());
            oAlumnosBO.Nombre = dtgAlumnos.Rows[FilaSeleccionada].Cells[1].Value.ToString();
            oAlumnosBO.Matricula=dtgAlumnos.Rows[FilaSeleccionada].Cells[2].Value.ToString();
            
            txtClave.Text =  oAlumnosBO.ID.ToString();
            txtNombre.Text= oAlumnosBO.Nombre;
            txtMatricula.Text = oAlumnosBO.Matricula;

            btnEliminar.Enabled = true;
            btnModificar.Enabled = true;
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Modificar(RecuperarInformacion()) == 1)
            { MessageBox.Show("Dato eliminado"); }
            else { MessageBox.Show("Hay un error llamar al: 9991435789"); }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }
    }
}
