﻿var EspacionTrabajo = Blockly.inject('blocklyGraficos',
    {
        toolbox: document.getElementById('MItoolbox'),
        zoom:
           {
               controls: true,
               wheel: true
           }
    });

function MostrarCodigo() {
    var code = Blockly.JavaScript.workspaceToCode(EspacionTrabajo);

    document.getElementById('CodigoAcompilar').innerHTML = code;

}

