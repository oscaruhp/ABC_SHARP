﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlumnosBD_2B.BO;

namespace AlumnosBD_2B.DAO
{
    class AlumnosDAO
    {
        Conexion Miconexion;
        public AlumnosDAO() {
            Miconexion = new Conexion();
        }

        public int Agregar(AlumnosBO oAlumnosBO) {

            String ComandoSQL = string.Format("INSERT INTO Alumnos(id,Nombre,Matricula) VALUES(null,'{0}','{1}')",oAlumnosBO.Nombre,oAlumnosBO.Matricula);
            return Miconexion.EjecutarComando(ComandoSQL);
 
        }
        public int Eliminar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("DELETE FROM Alumnos WHERE id={0}",oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);
        }
        public int Modificar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("UPDATE Alumnos SET Nombre='{0}',Matricula='{1}' WHERE id={2} ", oAlumnosBO.Nombre, oAlumnosBO.Matricula,oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);
        
        }
        public DataTable Buscar() {
            String ComandoSQL = string.Format("SELECT * FROM Alumnos");
            return Miconexion.EjercutarSentecia(ComandoSQL);
        }

    }
}
