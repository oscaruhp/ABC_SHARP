﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AlumnosBD_2B.BO;
using AlumnosBD_2B.DAO;

namespace AlumnosBD_2B.GUI
{
   
    public partial class frmAlumnosGUI : Form
    {
        AlumnosBO oAlumnosBO;
        AlumnosDAO oAlumnosDAO;

        public frmAlumnosGUI()
        {
            oAlumnosDAO = new AlumnosDAO();
            InitializeComponent();
           dtgAlumnos.DataSource= oAlumnosDAO.Buscar();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Agregar(RecuperarInformacion()) == 1)
            {
                MessageBox.Show("Se agrego el dato");
            }
            else {
                MessageBox.Show("Error: Llama al 9999999999");
            
            }

            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }
        private AlumnosBO RecuperarInformacion() {
            int id = 0;
            // Sí txtID (Clave de registro ) es vacío se reemplaza por 0
            int.TryParse(txtID.Text, out id);

            oAlumnosBO = new AlumnosBO();
            oAlumnosBO.ID = id;
            oAlumnosBO.Nombre = txtNombre.Text;
            oAlumnosBO.Matricula = txtMatricula.Text;
            return oAlumnosBO;

        }

        private void SeleccionarRegistro(object sender, DataGridViewCellMouseEventArgs e)
        {
            int FilaSeleccionada = e.RowIndex;
            oAlumnosBO = new AlumnosBO();
            oAlumnosBO.ID = int.Parse(dtgAlumnos.Rows[FilaSeleccionada].Cells[0].Value.ToString());

            oAlumnosBO.Nombre = dtgAlumnos.Rows[FilaSeleccionada].Cells[1].Value.ToString();
            oAlumnosBO.Matricula= dtgAlumnos.Rows[FilaSeleccionada].Cells[2].Value.ToString();


            txtID.Text =  oAlumnosBO.ID.ToString();
            txtNombre.Text = oAlumnosBO.Nombre;
            txtMatricula.Text = oAlumnosBO.Matricula;

            btnAgregar.Enabled = false;
            btnEliminar.Enabled = true;
            btnModificar.Enabled = true;
            btnCancelar.Enabled = true;

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            btnAgregar.Enabled = true;
            btnEliminar.Enabled = false;
            btnModificar.Enabled = false;
            btnCancelar.Enabled = false;
            LimpiarCampos();
        }
        public void LimpiarCampos() {
            txtID.Text = "";
            txtNombre.Text = "";
            txtMatricula.Text = "";
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Eliminar(RecuperarInformacion()) == 1)
            {
                MessageBox.Show("Registro Eliminado");
            }
            else {
                MessageBox.Show("Hay un problema para eliminar.");
            
            }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
            LimpiarCampos();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Modificar(RecuperarInformacion()) == 1)
            {
                MessageBox.Show("Registro modificado");
            }
            else
            {
                MessageBox.Show("Hay un problema para modificar.");

            }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
            LimpiarCampos();

        }

    }
}
