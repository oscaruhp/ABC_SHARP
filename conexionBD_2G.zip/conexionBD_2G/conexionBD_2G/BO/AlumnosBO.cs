﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conexionBD_2G.BO
{
   public class AlumnosBO
    {
        public int ID { get; set; }
        public String Nombre{get;set;}
        public String Matricula{get;set;}
    }
}
