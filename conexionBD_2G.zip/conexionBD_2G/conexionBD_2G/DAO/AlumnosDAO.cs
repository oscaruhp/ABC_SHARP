﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using conexionBD_2G.BO;
using System.Data;


namespace conexionBD_2G.DAO
{
    class AlumnosDAO
    {
        Conexion Miconexion;
        public AlumnosDAO() {
            Miconexion = new Conexion();
        }
        public DataTable Buscar() {
            return Miconexion.EjercutarSentecia("SELECT * FROM Alumnos");
        }


    }
}
