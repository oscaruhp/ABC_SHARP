﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using conexionBD_2G.BO;
using System.Data;


namespace conexionBD_2G.DAO
{
    public class AlumnosDAO
    {
        Conexion Miconexion;
        public AlumnosDAO() {
            Miconexion = new Conexion();
        }
        public DataTable Buscar() {
            return Miconexion.EjercutarSentecia("SELECT * FROM Alumnos");
        }
        public int Agregar(AlumnosBO oAlumnosBO) {
            String ComandoSQL = string.Format("INSERT INTO Alumnos(Nombre,Matricula) VALUES('{0}','{1}')",oAlumnosBO.Nombre,oAlumnosBO.Matricula);
            return Miconexion.EjecutarComando(ComandoSQL);
        }
        public int Eliminar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("DELETE FROM Alumnos WHERE id={0}", oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);
        }
        public int Modificar(AlumnosBO oAlumnosBO)
        {
            String ComandoSQL = string.Format("UPDATE Alumnos SET Nombre='{0}', Matricula='{1}' WHERE id={2}",oAlumnosBO.Nombre,oAlumnosBO.Matricula, oAlumnosBO.ID);
            return Miconexion.EjecutarComando(ComandoSQL);
        }


    }
}
