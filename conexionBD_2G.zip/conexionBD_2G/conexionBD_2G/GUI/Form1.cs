﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using conexionBD_2G.BO;
using conexionBD_2G.DAO;

namespace conexionBD_2G
{
    public partial class Form1 : Form
    {
        AlumnosBO oAlumnosBO;
        AlumnosDAO oAlumnosDAO;
        public Form1()
        {
            oAlumnosDAO = new AlumnosDAO();
            InitializeComponent();
            dtgAlumnos.DataSource= oAlumnosDAO.Buscar();

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Agregar(RetornarDatos()) == 1)
            {
                MessageBox.Show("Datos Agregados");
            }
            else {
                MessageBox.Show("Error: Llama al : 9999");
            }
            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();
        }
        public AlumnosBO RetornarDatos() {
            AlumnosBO oAlumnosBO = new AlumnosBO();
            oAlumnosBO.ID = Convert.ToInt32(txtID.Text);
            oAlumnosBO.Nombre = txtNombre.Text;
            oAlumnosBO.Matricula = txtMatricula.Text;
            return oAlumnosBO;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Eliminar(RetornarDatos()) == 1)
            {
                MessageBox.Show("Datos Eliminados");
            }
            else
            {
                MessageBox.Show("Error: Llama al : 9999");
            }

            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();

        }


        private void SeleccionarRegistro(object sender, DataGridViewCellMouseEventArgs e)
        {
            int FilaSeleccionada = e.RowIndex;

            txtID.Text = dtgAlumnos.Rows[FilaSeleccionada].Cells[0].Value.ToString();
            txtNombre.Text = dtgAlumnos.Rows[FilaSeleccionada].Cells[1].Value.ToString();
            txtMatricula.Text = dtgAlumnos.Rows[FilaSeleccionada].Cells[2].Value.ToString();
            
            oAlumnosBO = new AlumnosBO();
            oAlumnosBO.ID = int.Parse(txtID.Text);
            oAlumnosBO.Nombre = txtNombre.Text;
            oAlumnosBO.Matricula = txtMatricula.Text;

            btnAgregar.Enabled = false;
            btnEliminar.Enabled = true;
            btnModificar.Enabled = true;

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (oAlumnosDAO.Modificar(RetornarDatos()) == 1)
            {
                MessageBox.Show("Datos Modificados");
            }
            else
            {
                MessageBox.Show("Error: Llama al : 9999");
            }

            dtgAlumnos.DataSource = oAlumnosDAO.Buscar();

        }

    }
}
