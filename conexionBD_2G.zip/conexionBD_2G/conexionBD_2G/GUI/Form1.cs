﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using conexionBD_2G.BO;
using conexionBD_2G.DAO;

namespace conexionBD_2G
{
    public partial class Form1 : Form
    {
        AlumnosBO oAlumnosBO;
        AlumnosDAO oAlumnosDAO;
        public Form1()
        {
            oAlumnosDAO = new AlumnosDAO();
            InitializeComponent();
            dtgAlumnos.DataSource= oAlumnosDAO.Buscar();

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

        }
    }
}
